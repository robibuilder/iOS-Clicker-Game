//
//  Clicker_Game_v2App.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 7/27/21.
//

import SwiftUI

@main
struct Clicker_Game_v2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
