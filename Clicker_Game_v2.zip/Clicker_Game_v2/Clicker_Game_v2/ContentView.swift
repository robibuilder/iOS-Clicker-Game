//
//  ContentView.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 7/26/21.
//

import SwiftUI

struct UserPoints: Hashable {
    static func == (lhs: UserPoints, rhs: UserPoints) -> Bool {
        lhs.points == rhs.points
    }
    
    var points: Int = 0
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(floor(Double(points) / 100.0))
    }
}

struct ClickerMain: View {
    @State private var showDetails = false
    //@State private var userPoints = UserPoints(points: 0)
    //@State private var sliderVal = 5.0
    @State private var level = UIColor.systemGray
    @State private var lastScore = 1
    
    @Binding var userPoints: UserPoints
    //@Binding var points: Int
    @Binding var multiplier: Int
        
    var body: some View {
        ZStack {
            Color(level)
                .ignoresSafeArea()
            
            VStack {
                // smaller vstack w/ spacer at the bottom
                VStack {
                    Text("Beers: \(userPoints.points)")
                        .font(.system(size: 50))
                        .foregroundColor(.white)
                        //.padding()
                    Text("Beers/Click: \(multiplier)")
                        .font(.system(size: 25))
                        .foregroundColor(.white)
                        //.padding()

                }
                //.ignoresSafeArea(edges: .top)
                //.frame(height: 300)
                
                
                Button("Bing Bong!"){
                    var mult = 1.0
                    mult = mult * Double(multiplier)
                    userPoints.points = userPoints.points + Int(mult)
                    //points = userPoints.points
                    updateLevel()
                }
                .font(.custom("", size: 50))
                .frame(width: 300, height: 300)
                .foregroundColor(Color.white)
                .background(Color.blue)
                .clipShape(Circle())
                .overlay(
                    RoundedRectangle(cornerRadius: 1050)
                        .stroke(Color.white, lineWidth: 5))
                
                //.border(Color.white, width: 5)
                
//                HStack {
//                    Slider(
//                        value: $sliderVal,      // current position of slider
//                        in: 0...Double(userPoints.points),         // range
//                        step: 1         // range step
//                    ){
//
//                    }
//                }
//                .padding()
//
//                Text("\(sliderVal)")
//                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
//                    .foregroundColor(.white)
//                    .padding()
                
//                VStack{
//                    Text("Multiplier: \(multiplier)")
//                        .padding()
//                        .frame(height: 100)
//
//                }
                //Spacer()    // pushes all content in the stack to the top of the screen
            }
        }
        
    }
    
    func updateLevel() {
        if userPoints.points - lastScore > 1000 {
            let newColor = UIColor(hue: CGFloat(Double(abs(userPoints.hashValue) % 100) / 100.0), saturation: 0.5, brightness: 0.6, alpha: 1.0)
            level = newColor
            lastScore = userPoints.points
        }
        
    }
}

struct Store: View{
    
    @Binding var userPoints: UserPoints
    @Binding var multiplier: Int
    
    var body: some View{
        NavigationView{
            VStack{
                
                Button{
                    if(userPoints.points > 5) {
                        multiplier += 2
                        userPoints.points = userPoints.points - 5
                    }
                } label: {
                    VStack{
                        Text("+5")
                        Text("Price: 5")
                    }
                }
                .foregroundColor(.blue)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.blue, lineWidth: 5))
                Button{
                    if(userPoints.points > 10) {
                        multiplier += 10
                        userPoints.points = userPoints.points - 10
                    }
                } label: {
                    VStack{
                        Text("+10")
                        Text("Price: 10")
                    }
                }
                .foregroundColor(.blue)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.blue, lineWidth: 5))
                
                Button{
                    if(userPoints.points > 20) {
                        multiplier += 20
                        userPoints.points = userPoints.points - 20
                    }
                } label: {
                    VStack{
                        Text("+20")
                        Text("Price: 20")
                    }
                }
                .foregroundColor(.blue)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.blue, lineWidth: 5))
                
                Button{
                    if(userPoints.points > 200) {
                        multiplier += 50
                        userPoints.points = userPoints.points - 200
                    }
                } label: {
                    VStack{
                        Text("+50")
                        Text("Price: 200")
                    }
                }
                .foregroundColor(.blue)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.blue, lineWidth: 5))
                
                Button{
                    if(userPoints.points > 500) {
                        multiplier += 100
                        userPoints.points = userPoints.points - 500
                    }
                } label: {
                    VStack{
                        Text("+100")
                        Text("Price: 500")
                    }
                }
                .foregroundColor(.blue)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 40)
                        .stroke(Color.blue, lineWidth: 5))
            }
        }
    }
}

struct navView: View {
    @Binding var userPoints: UserPoints
    @Binding var multiplier: Int
    
    var body: some View {
        NavigationView{
            VStack{
                
            }
            .toolbar{
                ToolbarItemGroup(placement: .navigationBarLeading){
                    Text("Points: \(userPoints.points)")
                        .padding()
                        .font(.largeTitle)
                    Spacer()
                }
                ToolbarItemGroup(placement: .navigationBarTrailing){
                    Text("\(multiplier)/Click")
                        .padding()
                        .font(.largeTitle)
                    Spacer()
                }
            }
        }
    }
}


struct TabBar: View {
    //@State private var points = 1
    @State private var userPoints = UserPoints(points: 0)
    @State private var multiplier = 1
    
    var body: some View {
        
        TabView{
            NavigationView{
                ClickerMain(userPoints: $userPoints, multiplier: $multiplier)
            }
            .tabItem {
                Label("CLICK", systemImage: "gamecontroller.fill")
                Text("Clicker")
            }
            
            NavigationView{
                Store(userPoints: $userPoints, multiplier: $multiplier)
                    .toolbar{
                        ToolbarItemGroup(placement: .navigationBarLeading){
                            Text("Points: \(userPoints.points)")
                                .padding()
                                .font(.largeTitle)
                            Spacer()
                        }
                        ToolbarItemGroup(placement: .navigationBarTrailing){
                            Text("\(multiplier)/Click")
                                .padding()
                                .font(.largeTitle)
                            Spacer()
                        }
                    }
            }               .tabItem {
                Label("SHOP", systemImage: "cart.fill")
                Text("SHOP")
            }
        }
    }
}

struct ContentView: View {
    var body: some View {
        TabBar()
        //Store(userPoints: Binding.constant(UserPoints(points: 0)), multiplier: .constant(0))
        //navView(userPoints: Binding.constant(UserPoints(points: 0)), multiplier: .constant(0))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
