//
//  GridView.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 7/27/21.


import SwiftUI

var priceTest = 1

struct Cookie: Hashable {
    var multiplier: Int
    var price: Int
}

struct m: View{
    var x: Int
    var y: Int
    
    func incPrice(){
        priceTest+=1
        print("button pressed")
    }
    
    var body: some View {
        VStack{
            Button{
                incPrice()
            } label: {
                VStack{
                    Text("X\(x)")
                    Text("Price: \(priceTest)")
                }
            }
        }
    }
}



struct GridView: View {
    let data = Array(2...30).map { "\($0)x multiplier" }
    
    //var arr:Array<Cookie> = Array<Cookie>(1...5)
    
    //@State private var price = 100
    
    //@State private var inStock = true
    
    //var cookie: Cookie// = Cookie(multiplier: 2, price: 4)
    var mul: Int
    var price: Int
        
    let layout = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ScrollView{
            LazyVGrid(columns: layout, spacing: 20) {
                ForEach(data, id: \.self) { item in
                    VStack {
//                        Text("mult: \(mul)")
//                        Text("Price: \(price)")
                        m(x: mul, y: priceTest)
                    }
                }
            }
        }
        .padding()
    }
}

struct GridView_Previews: PreviewProvider {
    static var previews: some View {
        GridView(mul: 1, price: 2)
    }
}
