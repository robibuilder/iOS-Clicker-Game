//
//  PointsBar.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 11/1/21.
//

import SwiftUI

struct PointsBar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct PointsBar_Previews: PreviewProvider {
    static var previews: some View {
        PointsBar()
    }
}
