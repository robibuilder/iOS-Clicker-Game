//
//  Store.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 11/1/21.
//

import SwiftUI

struct Store2: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Store_Previews: PreviewProvider {
    static var previews: some View {
        Store2()
    }
}
