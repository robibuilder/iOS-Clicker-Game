//
//  Tabs.swift
//  Clicker_Game_v2
//
//  Created by Jacob Robinett on 11/1/21.
//

import SwiftUI

struct Tabs: View {
    var body: some View {
        TabView(){
            Store2()
                .tabItem{
                    Label("Home", systemImage: "gamecontroller.fill")
                    Text("Store")
                }
                .tag(0)
            
            Store2()
                .tabItem{
                    Label("Store", systemImage: "cart.fill")
                    Text("Store")
                }
                .tag(1)
        }
    }
}

struct Tabs_Previews: PreviewProvider {
    static var previews: some View {
        Tabs()
    }
}
